# Atelier Storefront

Atelier Storefront is fictional portfolio work for CS-Cart 4.21.1. It demonstrates an upgrade-safe storefront customization built as an add-on instead of direct core edits.

## What is included

- Smarty hook templates under `var/themes_repository/responsive/templates/addons/atelier_storefront`.
- LESS source under `var/themes_repository/responsive/css/addons/atelier_storefront`.
- AJAX-safe storefront JavaScript under `var/themes_repository/responsive/js/addons/atelier_storefront`.
- Add-on metadata under `app/addons/atelier_storefront`.
- A standalone visual preview under `preview`.

## Install in CS-Cart

1. Copy the included files into the matching directories of a CS-Cart 4.21.1 installation.
2. Open **Add-ons > Manage add-ons** in the administration panel.
3. Find **Atelier Storefront Demo** and install or enable it.
4. Clear the CS-Cart cache.
5. Open a product page using the Responsive theme and verify the purchase-information component below the product form.

## Architecture

The implementation uses public template hooks. It does not replace product templates or modify CS-Cart core files. Styles are scoped to the add-on component, with a small deliberate pass over standard button, heading, product-image, and product-grid selectors. JavaScript subscribes to `ce.commoninit`, so it also handles fragments rendered through CS-Cart AJAX.

## Preview

Open `preview/index.html` through any local static server. The preview provides product filtering, mobile navigation, and simulated add-to-bag feedback. It contains no checkout, payment, order, or customer backend.

## Local CS-Cart demo

The repository also includes a Docker-based CS-Cart 4.21.1 demo environment.

```powershell
docker compose up --build -d
```

- Storefront: `http://127.0.0.1:8088/`
- Administration: `http://127.0.0.1:8088/atelier-admin.php`
- Local demo administrator: `admin@atelier-demo.local` / `AtelierDemo!2026`

These credentials and database passwords are development-only. Do not reuse them on a public server. The installer is renamed to `installer-disabled` after setup and the administration entry point is deliberately non-default.

The first local installation was seeded with CS-Cart's fictional demo catalog. Atelier Storefront Demo is enabled through the add-on manager and adds its service component through public hooks.

## Honest portfolio note

This is a self-directed demo, not client work. It is based on CS-Cart Responsive and has not been tested with a licensed UniTheme2 installation.
