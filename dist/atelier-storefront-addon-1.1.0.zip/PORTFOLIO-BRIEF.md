# Atelier Storefront | CS-Cart customization demo

This is fictional portfolio work built on CS-Cart 4.21.1. It is not client work and does not claim UniTheme2 experience.

## Goal

Demonstrate maintainable CS-Cart storefront work: Smarty templates, LESS styling, template hooks, add-on packaging, responsive behavior, and upgrade-safe changes without editing the platform core.

## Delivered system

- Installable `atelier_storefront` add-on for CS-Cart 4.21.1.
- Product-detail service component injected through `products:product_detail_bottom`.
- Theme styling loaded through `index:styles` and JavaScript through `index:scripts`.
- Central LESS tokens for color, shape, typography, controls, product media, and responsive states.
- Progressive JavaScript that remains safe across CS-Cart AJAX reinitialization.
- Standalone interactive preview that mirrors the visual direction for portfolio review.

## Boundary

The add-on is real source code. The browser preview is a visual companion and does not pretend to be a running CS-Cart backend. Installation and end-to-end checkout verification remain pending until the local Docker engine is available.

## Evidence to capture

1. Desktop product page with the assurance component.
2. Mobile product page at 390 px.
3. Category grid after the visual pass.
4. CS-Cart add-on page showing `Atelier Storefront Demo` enabled.
5. Code view showing `product_detail_bottom.post.tpl` and `styles.less`.

## Honest positioning

Use the title `CS-Cart Responsive Theme Customization | Smarty, LESS & Hooks`. Do not mention UniTheme2 unless the work is later tested on a licensed UniTheme2 installation.
